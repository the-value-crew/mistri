$(document).ready(function() {

	

	var select=$('.form-group select');
	let offset = $('.progressive--wrapper').offset();
	const slideHide = ()=>{
		$('.step').hide('300');
		$('html, body').scrollTop(offset.top)
		
	}
	const slideShow = elem=>{
		elem.show('300');
		elem.addClass('active');

		$('html, body').animate({
			scrollTop: offset.top,
		}, 300);
	}

	var valueAdd= (100/($('.progressive--wrapper .label span').length-1));

	$('.progress-bar').css('width',valueAdd+'%');

	var tempValue= valueAdd;

	const progressInc= ()=>{
		tempValue+=valueAdd;
		$('.progress-bar').css('width',tempValue+'%');
	}

	const progressDec= ()=>{ 
		tempValue-=valueAdd;
		$('.progress-bar').css('width',tempValue+'%');

	}

 		// step 01
 		$('.step.step--1 .button__next').click((e)=>{
 			e.preventDefault();
 			slideHide();
 			slideShow($('.step.step--2'));

 			progressInc();
 			$(e.target).parents('.step').removeClass('active')
 			$('.progressive--wrapper .label span:nth-child(2)').addClass('active');
 		});

 		// step 02
 		$('.step.step--2 .button__next').click((e)=>{
 			e.preventDefault();
 			slideHide();
 			slideShow($('.step.step--3'));
 			progressInc();
 			$(e.target).parents('.step').removeClass('active');
 			$('.progressive--wrapper .label span:nth-child(3)').addClass('active');
 			$('.checkout--wrapper button.checkout').removeAttr('disabled');
 			
 			// $('button.select--button').show();

 		});

 		$('.step.step--2 .button__prev').click((e)=>{
 			e.preventDefault();
 			slideHide();
 			progressDec();
 			slideShow($('.step.step--1'));
 			$(e.target).parents('.step').removeClass('active')
 			$(e.target).parents('.step').prev().addClass('active');
 			$('.progressive--wrapper .label span:nth-child(2)').removeClass('active');
 		})

 		// step 03
 		$('.step.step--3 .button__next').click((e)=>{
 			e.preventDefault();
 			slideHide();
 			slideShow($('.step.step--4'));
 			progressInc();
 			$(e.target).parents('.step').removeClass('active');
 			$('.progressive--wrapper .label span:nth-child(4)').addClass('active');

 		});

 		$('.step.step--3 .button__prev').click((e)=>{
 			e.preventDefault();
 			slideHide();
 			progressDec();
 			slideShow($('.step.step--2'));
 			$(e.target).parents('.step').removeClass('active')
 			$(e.target).parents('.step').prev().addClass('active');
 			$('.progressive--wrapper .label span:nth-child(3)').removeClass('active');
 			$('.checkout--wrapper button.checkout').attr('disabled','')

 		});
 		$('.checkout--wrapper button.checkout').click(()=>{
 			$('.progress-bar').css('width','100%');
 			$('.progressive--wrapper .label span:last-child').addClass('active');
 		})

 		// $('input[type=date]').hover(function(e){
 		// 	$(this).focus();
 		// 	$(this).click();
 		// 	$(this).parent().data("DateTimePicker").show();
 		// })
 		
 		// $('input[type=date]').datetimepicker({                            
 		// 	allowInputToggle: true
 		// });

 		

 		



 	});